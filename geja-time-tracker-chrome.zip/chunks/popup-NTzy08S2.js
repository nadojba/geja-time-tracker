import{c as e,j as t,r,A as o}from"./App-FoC8U8bZ.js";e.createRoot(document.getElementById("root")).render(t.jsx(r.StrictMode,{children:t.jsx(o,{})}));
